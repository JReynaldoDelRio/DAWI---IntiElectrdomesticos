package com.inti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntiElectrodomesticosApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntiElectrodomesticosApplication.class, args);
	}

}
